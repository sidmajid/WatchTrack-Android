# WatchTrack Source Bundle

Includes the website in `web/`, the Android WebView project in `android/WatchTrack-Android/`, and the project coding/design standards in `AGENTS.md` and `docs/ENGINEERING_STANDARDS.md`. Each component has its own README.

Run the website with `python -m http.server 8000 --directory web`. Enter your own TMDB API Read Access Token in **TMDB Setup**.

Build Android with Java 17, Android SDK platform 35, and Gradle 8.9: `cd android/WatchTrack-Android && gradle assembleDebug`.

Never commit your TMDB token. This product uses the TMDB API but is not endorsed or certified by TMDB.
